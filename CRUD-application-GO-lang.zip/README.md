# CRUD application in GO or GO Lang

This is basic CRUD app, whihc uses to GO/Go Lang as web server. MySql is used as Databse to store records and for Front end I am using Plain old AngularJs.

## Installtion

Below command will Install all the dependencies recursively. 

```bash
go get -d ./...
```

## Starting the GO server

Below command will start the GO server.

```bash
go run *.go
```

